let handler = async (m, { conn, command }) => {
  await conn.reply(m.chat, wait, m)
  try {
    if (command == 'gay') {
      const res = `https://api.betabotz.eu.org/api/nsfw/gay?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ahegao') {
      const res = `https://api.betabotz.eu.org/api/nsfw/ahegao?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ass') {
      const res = `https://api.betabotz.eu.org/api/nsfw/ass?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'bdsm') {
      const res = `https://api.betabotz.eu.org/api/nsfw/bdsm?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'blowjob') {
      const res = `https://api.betabotz.eu.org/api/nsfw/blowjob?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
     if (command == 'cuckold') {
      const res = `https://api.betabotz.eu.org/api/nsfw/cuckold?apikey=ct${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'cum') {
      const res = `https://api.betabotz.eu.org/api/nsfw/cum?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ero') {
      const res = `https://api.betabotz.eu.org/api/nsfw/ero?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'femdom') {
      const res = `https://api.betabotz.eu.org/api/nsfw/femdom?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'foot') {
      const res = `https://api.betabotz.eu.org/api/nsfw/foot?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'gangbang') {
      const res = `https://api.betabotz.eu.org/api/nsfw/gangbang?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'glasses') {
      const res = `https://api.betabotz.eu.org/api/nsfw/glasses?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'hentai') {
      const res = `https://api.betabotz.eu.org/api/nsfw/hentai?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'gifs') {
      const res = `https://api.betabotz.eu.org/api/nsfw/gifs?apikey=${lann}`;
      await conn.sendFile(m.chat, res, null, '', m);
    }
    if (command == 'jahy') {
      const res = `https://api.betabotz.eu.org/api/nsfw/jahy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'manga') {
      const res = `https://api.betabotz.eu.org/api/nsfw/manga?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'masturbation') {
      const res = `https://api.betabotz.eu.org/api/nsfw/masturbation?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'neko') {
      const res = `https://api.betabotz.eu.org/api/nsfw/neko?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'neko2') {
      const res = `https://api.betabotz.eu.org/api/nsfw/neko2?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'orgy') {
      const res = `https://api.betabotz.eu.org/api/nsfw/orgy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'panties') {
      const res = `https://api.betabotz.eu.org/api/nsfw/panties?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'pussy') {
      const res = `https://api.betabotz.eu.org/api/nsfw/pussy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'tentacles') {
      const res = `https://api.betabotz.eu.org/api/nsfw/tentacles?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'yuri') {
      const res = `https://api.betabotz.eu.org/api/nsfw/yuri?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'thighs') {
      const res = `https://api.betabotz.eu.org/api/nsfw/thighs?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'zettai') {
      const res = `https://api.betabotz.eu.org/api/nsfw/zettai?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
   } catch (err) {
  console.error(err)
  throw "🚩 Terjadi kesalahan"
   };
};
handler.command = handler.help = ['gay','ahegao','ass','bdsm','blowjob','cuckold','cum','ero','femdom','foot','gangbang','glasses','hentai','gifs','jahy','manga','masturbation','neko','neko2','orgy','tentacles','pussy','panties','thighs','yuri','zettai']
handler.tags = ['nsfw']
handler.limit = true;
module.exports = handler;
